<!--@author 'Victor Alagwu';
//  @project 'Simple Content Management System';
//  @date    '0ctober 2016'; -->
 <footer class="foo">
            <div class="row">
                <div class="col-lg-12">

                    <p style="text-align:center; font-family: 'Monotype Corsiva'; font-size:17px;"><i  class="fa fa-fw fa-code"></i> with <i class="material-icons" style="color: red;">favorite</i> from <b >Victor Alagwu</b></p>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
   </footer>