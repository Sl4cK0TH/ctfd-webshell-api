# Commited 
---

## About the Project

Commited is our project created to manage our databases, Commited will bring help our database management team by simplfying database management by using our python scripts.

## Project Status

Completed.

## Team

Our development team consists of finest developers and we work simultaneously using our cool version control methodology. We are the BEST.
